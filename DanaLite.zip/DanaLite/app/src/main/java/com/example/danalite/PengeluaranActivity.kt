package com.example.danalite

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class PengeluaranActivity : AppCompatActivity() {
    private lateinit var editTextJumlah: EditText
    private lateinit var editTextKeterangan: EditText
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pengeluaran)

        editTextJumlah = findViewById(R.id.editTextJumlahPengeluaran)
        editTextKeterangan = findViewById(R.id.editTextKeteranganPengeluaran)
        val buttonSimpan = findViewById<Button>(R.id.buttonSimpanPengeluaran)

        databaseHelper = DatabaseHelper(this)

        buttonSimpan.setOnClickListener {
            val jumlah = editTextJumlah.text.toString().toIntOrNull()
            val keterangan = editTextKeterangan.text.toString()

            if (jumlah != null && keterangan.isNotEmpty()) {
                // Menambahkan data ke database
                databaseHelper.addTransaksi(DataModel("Pengeluaran", jumlah, keterangan))
                finish() // Kembali ke activity sebelumnya setelah menyimpan
            } else {
                // Tampilkan pesan kesalahan jika input tidak valid
                if (jumlah == null) {
                    editTextJumlah.error = "Jumlah harus berupa angka"
                }
                if (keterangan.isEmpty()) {
                    editTextKeterangan.error = "Keterangan tidak boleh kosong"
                }
            }
        }
    }
}