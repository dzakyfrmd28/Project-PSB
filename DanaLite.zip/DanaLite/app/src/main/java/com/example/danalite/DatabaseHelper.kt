package com.example.danalite

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "keuangan.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "transaksi"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TIPE = "tipe"
        private const val COLUMN_JUMLAH = "jumlah"
        private const val COLUMN_KETERANGAN = "keterangan"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE $TABLE_NAME ($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$COLUMN_TIPE TEXT, "
                + "$COLUMN_JUMLAH INTEGER, "
                + "$COLUMN_KETERANGAN TEXT)")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // Menambahkan transaksi
    fun addTransaksi(transaksi: DataModel) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TIPE, transaksi.tipe)
            put(COLUMN_JUMLAH, transaksi.jumlah)
            put(COLUMN_KETERANGAN, transaksi.keterangan)
        }
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    // Mengambil semua transaksi
    fun getAllTransaksi(): List<DataModel> {
        val transactions = mutableListOf<DataModel>()
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

        if (cursor.moveToFirst()) {
            do {
                val tipe = cursor.getString(cursor.getColumnIndex(COLUMN_TIPE))
                val jumlah = cursor.getInt(cursor.getColumnIndex(COLUMN_JUMLAH))
                val keterangan = cursor.getString(cursor.getColumnIndex(COLUMN_KETERANGAN))
                transactions.add(DataModel(tipe, jumlah, keterangan))
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return transactions
    }
}