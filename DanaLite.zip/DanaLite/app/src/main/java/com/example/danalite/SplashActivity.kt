package com.example.danalite

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Menentukan durasi splash screen
        val splashTime: Long = 3000 // 3 detik

        Handler().postDelayed({
            // Arahkan ke MainActivity setelah splash screen
            startActivity(Intent(this, MainActivity::class.java))
            finish() // Menutup SplashActivity
        }, splashTime)
    }
}