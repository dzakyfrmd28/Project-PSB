package com.example.danalite

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DataActivity : AppCompatActivity() {
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data)

        databaseHelper = DatabaseHelper(this)

        // Inisialisasi RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewData)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Ambil data dari database
        val dataList = databaseHelper.getAllTransaksi()
        recyclerView.adapter = DataAdapter(dataList) // Menampilkan data di RecyclerView
    }
}