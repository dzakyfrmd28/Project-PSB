package com.example.danalite

data class DataModel(
    val tipe: String,      // "Pemasukan" atau "Pengeluaran"
    val jumlah: Int,       // Jumlah uang
    val keterangan: String // Keterangan
)