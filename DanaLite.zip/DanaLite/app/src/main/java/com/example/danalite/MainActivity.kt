package com.example.danalite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonPemasukan = findViewById<Button>(R.id.buttonPemasukan)
        val buttonPengeluaran = findViewById<Button>(R.id.buttonPengeluaran)
        val buttonLihatData = findViewById<Button>(R.id.buttonLihatData)
        buttonLihatData.setOnClickListener {
            val intent = Intent(this, DataActivity::class.java)
            startActivity(intent)
        }

        buttonPemasukan.setOnClickListener {
            startActivity(Intent(this, PemasukanActivity::class.java))
        }

        buttonPengeluaran.setOnClickListener {
            startActivity(Intent(this, PengeluaranActivity::class.java))
        }
    }
}